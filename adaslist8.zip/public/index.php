<?php
/**
 *  Silence is golden
 */
